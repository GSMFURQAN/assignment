// import './App.css';
import Article from './Components/Cards.jsx/Article';
import MainCard from './Components/Cards.jsx/MainCard';
import SubCard from './Components/Cards.jsx/LeftCards';

function App() {
  return (
    <div className="container mt-4" >
     <MainCard/>
     <Article/>
    </div>
  );
}

export default App;
